Grand Theft Auto IV: Story Mode Co-op (1.0.7.0 / 1.0.8.0)
=========================================================

RU — Как запустить сюжетный кооп:
1. Требуется отдельная копия GTA IV, откатанная до патча 1.0.7.0 или 1.0.8.0
   (не затирайте основную Steam / Complete Edition v1.2.0.59 папку).
2. Подключитесь с другом в одну сеть Radmin VPN (или используйте встроенный
   хаб XLLN `glitchyscripts.com:1100` в `GTAIV/XLiveLessNess/xlln-config-1.ini`).
3. Запустите игру через Fusion Launcher. В игре нажмите:
   - `Home` — меню XLiveLessNess (профиль и сеть);
   - телефон -> Multiplayer — создать или войти в лобби с другом;
   - `F7` — меню ZMenu IV -> включите режим **Co-op / SP Story Mode Co-op**.
4. Опциональный слой `GTAIV.EFLC.FusionFix-GFWL` уже включён по умолчанию
   (улучшенная графика и фикс высокого FPS с сохранением мультиплеера).

EN — How to play Story Mode Co-op:
1. Requires a separate GTA IV installation downgraded to patch 1.0.7.0 or 1.0.8.0
   (keep your main v1.2.0.59 Steam / Complete Edition installation untouched).
2. Join the same Radmin VPN network with your friend (or use the default XLLN hub
   `glitchyscripts.com:1100` configured in `GTAIV/XLiveLessNess/xlln-config-1.ini`).
3. Launch via Fusion Launcher. In-game:
   - Press `Home` for XLiveLessNess network/profile settings;
   - Use the in-game phone -> Multiplayer to host or join your friend's lobby;
   - Press `F7` for **ZMenu IV** and enable **Co-op / SP Story Mode Co-op**.
4. The optional `GTAIV.EFLC.FusionFix-GFWL` layer is enabled by default for
   visual improvements and high-FPS fixes while preserving multiplayer.
