Grand Theft Auto IV — Remastered (Fusion Source v1.1.0)
========================================================

Non-destructive graphics & QoL stack layered over your own GTA IV: Complete Edition (v1.2.0.59):

- GTAIV.EFLC.FusionFix v5.1.2 (pinned directly from ThirteenAG/GTAIV.EFLC.FusionFix GitHub Releases):
  console shaders, volumetric fog, enhanced shadows, bloom, sunshafts, high-FPS physics fixes,
  and an in-game Vulkan / DXVK graphics toggle in Options -> Graphics.
- IV.Project2DFX (optional addon, enabled by default):
  distant night LOD lights across Liberty City, pinned directly from ThirteenAG/III.VC.SA.IV.Project2DFX.
- Fusion Remastered Config:
  mounts GTAIV/commandline.txt (-nomemrestrict -norestrictions) as a writable copy alongside
  GTAIV/plugins/GTAIV.EFLC.FusionFix.ini without touching your original game directory.
